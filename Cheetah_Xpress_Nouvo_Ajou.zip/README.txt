CHEETAH XPRESS — NOUVO VÈSYON

Fichye yo:
- index.html : paj katalòg la, ak pri promo yo mete ajou.
- afich-cheetah-xpress.png : afich ki deja entegre nan paj la.

Pou mete sou GitHub Pages:
1. Louvri repozitwa Cheetah-Top-up.
2. Ranplase ansyen index.html ak nouvo index.html.
3. Ajoute afich-cheetah-xpress.png nan menm nivo ak index.html.
4. Commit chanjman yo sou branch principal.

Nimewo WhatsApp/NatCash nan paj la: +509 3551-4145
MonCash: +509 4490-3997
